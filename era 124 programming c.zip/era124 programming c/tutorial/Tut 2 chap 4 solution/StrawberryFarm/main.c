#include <stdio.h>
#include "strawberry.h"

// Main function
int main(void) {
    int totalWeight, numStudents;

    totalWeight = GetInput("Enter total weight of strawberries (kg): ");
    numStudents = GetInput("Enter number of students: ");

    Calculate(totalWeight, numStudents);

    return 0;
}
